package udemy;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Demom1 {

	int x=2;
	int y=1;
	int z=1;
	
	boolean a=(x==y);
	boolean b=(y==z);
	
	@Test
	public void test1(){
		assertNotEquals(x,y);
	}
	@Test
	public void test2() {assertEquals(y, z);}
	
	@Test
	public void test3() {
		assertFalse(a);
	}
	@Test
	public void test4() {
		assertTrue(b);
	}
}
