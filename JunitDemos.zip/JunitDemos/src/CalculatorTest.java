import org.junit.Test;

import junit.framework.Assert;

public class CalculatorTest {


	@Test
	public void testAdd() {
	Calculator calc=new Calculator();
	Assert.assertEquals(4, calc.add(2, 2));
	Assert.assertEquals(8, calc.add(2, 6));
	Assert.assertEquals(40, calc.add(20, 20));}
	@Test
	public void testDivide() {
	Calculator calc=new Calculator();
	Assert.assertEquals(2, calc.divide(10, 5));
	Assert.assertEquals(0, calc.divide(20, 0));
	}


}
