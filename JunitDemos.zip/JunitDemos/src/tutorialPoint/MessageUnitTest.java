package tutorialPoint;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;


public class MessageUnitTest {
	
	String msg="Sahi";
	
	MessageUnit mu= new MessageUnit(msg);
	@Ignore
	@Test
	public void testmsg() {
		assertEquals(msg, mu.say());
		
	}

}
