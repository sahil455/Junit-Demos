package tutorialPoint;

import org.junit.Test;

public class Test2 {
	
	@Test
	public void test2()
	{
		System.out.println("2");
	}

}
