package tutorialPoint;

import org.junit.Test;

public class Test1 {

	@Test
	public void test1()
	{
		
		System.out.println("1");
	}
}
