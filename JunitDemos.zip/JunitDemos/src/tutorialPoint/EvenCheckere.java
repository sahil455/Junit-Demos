package tutorialPoint;

public class EvenCheckere {
	
	public Boolean validate(final int n) {
		if(n%2==0)
			return true;
		else 
			return false;
	}

}
