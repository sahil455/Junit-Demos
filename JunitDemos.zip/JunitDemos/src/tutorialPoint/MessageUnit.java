package tutorialPoint;

public class MessageUnit {
	
	private String msg;
	public MessageUnit(String msg) {
		// TODO Auto-generated constructor stub
		this.msg=msg;
	}
	public String say() {return (msg);}
	public void sayHello() {System.out.println("Hello "+msg);}

}
