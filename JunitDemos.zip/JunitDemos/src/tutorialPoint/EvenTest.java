package tutorialPoint;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class EvenTest {
	
	private final Integer inp;
	private final Boolean exp;
	private EvenCheckere e;
	
	@Before
	public void initoialize()
	{
		e= new EvenCheckere();
	}
	
	public EvenTest(Integer inp, Boolean exp) {
		super();
		this.inp = inp;
		this.exp = exp;
	}


	@Parameterized.Parameters
	public static Collection evenNums() {
		return Arrays.asList(new Object[][] {{1,false},{2,true},{4,true},{3,false}} );
	}
	
	@Test
	public void test() {
		assertEquals(exp, e.validate(inp));
	}
}
