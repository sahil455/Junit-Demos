
public class Calculator {
	
	public int add(int num1, int num2) {
		return num1 + num2;
		}
		public int divide(int num1, int num2)  {
			int result=0;
			try{
			result=num1 / num2;
			}catch(Exception ex){
			//Exception Handling code
			}
			return result;		}
		
}
